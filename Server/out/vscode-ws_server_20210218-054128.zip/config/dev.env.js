module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  BASE_API: '"http://localhost:5000/odata/"',
  COUCHDB_API: '"http://admin:admin@localhost:5984/"'
}
