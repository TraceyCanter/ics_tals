module.exports = {
  PORT: 80,
  NODE_ENV: '"production"',
  ENV_CONFIG: '"prod"',
}